﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract5
{
    /// <summary>
    /// Логика взаимодействия для AdminPageDanVxod.xaml
    /// </summary>
    public partial class AdminPageDanVxod : Page
    {
        private pract6Entities context = new pract6Entities();
        public AdminPageDanVxod()
        {
            InitializeComponent();
            tablic.ItemsSource = context.Vhod.ToList();
            Cb1.ItemsSource = context.Role.ToList(); // запись в комбобокс данных из таблицы
        }
        private void BtDob_Cl(object sender, RoutedEventArgs e)
        {
            Vhod o = new Vhod();
            if (text1.Text == "")
            {
                Eror.Text = "Невозможно добавить сотрудника: \nОтсутствует логин";
                return;
            }
            else
            {
                o.Login = Convert.ToString(text1.Text);
            }
            if (text2.Password == "")
            {
                Eror.Text = "Невозможно добавить данные: \nОтсутствует пароль";
                return;
            }
            else
            {
                o.Password = Convert.ToString(text2.Password);
            }

            if (Cb1.SelectedItem != null)
            {
                var selected = Cb1.SelectedItem as Role;
                o.Role_ID = Convert.ToInt32(selected.ID_Role);
            }
            try
            {
                context.Vhod.Add(o);
                context.SaveChanges();
                tablic.ItemsSource = context.Vhod.ToList();
            }
            catch
            {
                Eror.Text = "Невозможно добавить данные:\nОтсутствует роль";
            }
        }
        private void BtIzm_Cl(object sender, RoutedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Vhod;

                if (text1.Text == "")
                {
                    Eror.Text = "Невозможно изменить сотрудника: \nОтсутствует логин";
                    return;
                }
                else
                {
                    selected.Login = Convert.ToString(text1.Text);
                }
                if (text2.Password == "")
                {
                    Eror.Text = "Невозможно изменить данные: \nОтсутствует пароль";
                    return;
                }
                else
                {
                    selected.Password = Convert.ToString(text2.Password);
                }

                if (Cb1.SelectedItem != null)
                {
                    var selected1 = Cb1.SelectedItem as Role;
                    selected.Role_ID = Convert.ToInt32(selected1.ID_Role);
                }
                try
                {
                    context.SaveChanges();
                    tablic.ItemsSource = context.Vhod.ToList();
                }
                catch
                {
                    Eror.Text = "Невозможно изменить данные:\nОтсутствует роль";
                }
            }
        }
        private void BtDel_Cl(object sender, RoutedEventArgs e)
        {
            var selected = tablic.SelectedItem as Vhod;
            if (selected != null)
            {
                try
                {
                    context.Vhod.Remove(selected);
                    context.SaveChanges();
                    tablic.ItemsSource = context.Vhod.ToList();
                }
                catch
                {
                    Eror.Text = "Невозможно удалить данные\nтак как они привязан к сотруднику";
                }
            }
        }
        private void tablic_Dob(object sender, SelectionChangedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Vhod;

                text1.Text = selected.Login.ToString();
                text2.Password = selected.Password.ToString();
                if (selected.Role != null)
                {
                    Cb1.Text = selected.Role.Role_Name.ToString();
                }
                else
                {
                    Cb1.Text = "";
                }
            }
        }
    }
}