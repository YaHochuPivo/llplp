﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract5
{
    /// <summary>
    /// Логика взаимодействия для AdminPageRol.xaml
    /// </summary>
    public partial class AdminPageRol : Page
    {
        private pract6Entities context = new pract6Entities();
        public AdminPageRol()
        {
            InitializeComponent();
            tablic.ItemsSource = context.Role.ToList();
        }
        private void BtDob_Cl(object sender, RoutedEventArgs e)
        {
            Role o = new Role();
            if (text1.Text == "")
            {
                Eror.Text = "Невозможно добавить роль: \nРоль отсутствует";
                return;
            }
            else
            {
                o.Role_Name = Convert.ToString(text1.Text);
            }
            try
            {
                context.Role.Add(o);
                context.SaveChanges();
                tablic.ItemsSource = context.Role.ToList();
            }
            catch
            {
                Eror.Text = "Невозможно добавить роль\nтак как она уже существует";
            }
        }
        private void BtIzm_Cl(object sender, RoutedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Role;
                if (text1.Text == "")
                {
                    Eror.Text = "Невозможно изменить роль: \nРоль отсутствует";
                    return;
                }
                else
                {
                    selected.Role_Name = Convert.ToString(text1.Text);
                }

                try
                {
                    context.SaveChanges();
                    tablic.ItemsSource = context.Role.ToList();
                }
                catch
                {
                    Eror.Text = "Невозможно изменить роль\nтак как она уже существует";
                }
            }
        }
        private void BtDel_Cl(object sender, RoutedEventArgs e)
        {
            var selected = tablic.SelectedItem as Role;
            if (selected != null)
            {
                try
                {
                    context.Role.Remove(selected);
                    context.SaveChanges();
                    tablic.ItemsSource = context.Role.ToList();
                }
                catch
                {
                    Eror.Text = "Невозможно удалить роль\nтак как она привязан к данным для входа";
                }
            }
        }
        private void tablic_Dob(object sender, SelectionChangedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Role;

                text1.Text = selected.Role_Name.ToString();
            }
        }
    }
}