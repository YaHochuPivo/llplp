﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract5
{
    /// <summary>
    /// Логика взаимодействия для AdminPageEMPDolz.xaml
    /// </summary>
    public partial class AdminPageEMPDolz : Page
    {
        private pract6Entities context = new pract6Entities();
        public AdminPageEMPDolz()
        {
            InitializeComponent();
            tablic.ItemsSource = context.Sotr_Dolzh.ToList();
            Cb1.ItemsSource = context.Info_Dolzhnost.ToList();
            Cb2.ItemsSource = context.Dolzhnost.ToList();
        }

        private void BtDob_Cl(object sender, RoutedEventArgs e)
        {
            Sotr_Dolzh o = new Sotr_Dolzh();

            if (Cb1.SelectedItem != null)
            {
                var selected = Cb1.SelectedItem as Info_Dolzhnost;
                o.Info_ID = Convert.ToInt32(selected.ID_Info);
            }

            if (Cb2.SelectedItem != null)
            {
                var selected2 = Cb2.SelectedItem as Dolzhnost;
                o.Dolzh_ID = Convert.ToInt32(selected2.ID_Dolzh);
            }
            try
            {
                context.Sotr_Dolzh.Add(o);
                context.SaveChanges();
                tablic.ItemsSource = context.Sotr_Dolzh.ToList();
            }
            catch
            {
                Eror.Text = "Невозможно добавить данные:\nСотрудник или должность невыбраны";
            }
        }

        private void BtDel_Cl(object sender, RoutedEventArgs e)
        {
            var selected = tablic.SelectedItem as Sotr_Dolzh;
            if (selected != null)
            {
                context.Sotr_Dolzh.Remove(selected);
                context.SaveChanges();
                tablic.ItemsSource = context.Sotr_Dolzh.ToList();
            }
        }

        private void BtIzm_Cl(object sender, RoutedEventArgs e)
        {
            var selected = tablic.SelectedItem as Sotr_Dolzh;

            if (Cb1.SelectedItem != null)
            {
                var selected1 = Cb1.SelectedItem as Info_Dolzhnost;
                selected.Info_ID = Convert.ToInt32(selected1.ID_Info);
            }

            if (Cb2.SelectedItem != null)
            {
                var selected1 = Cb2.SelectedItem as Dolzhnost;
                selected.Dolzh_ID = Convert.ToInt32(selected1.ID_Dolzh);
            }

            try
            {
                context.SaveChanges();
                tablic.ItemsSource = context.Sotr_Dolzh.ToList();
            }
            catch
            {
                Eror.Text = "Невозможно изменить данные:\nСотрудник или должность невыбраны";
            }
        }
        private void tablic_Dob(object sender, SelectionChangedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Sotr_Dolzh;

                if (selected.Info_Dolzhnost != null)
                {
                    Cb1.Text = selected.Info_Dolzhnost.Surname_Sotr.ToString();
                }
                else
                {
                    Cb1.Text = "";
                }
                if (selected.Dolzhnost != null)
                {
                    Cb2.Text = selected.Dolzhnost.Dolzhnost_Name.ToString();
                }
                else
                {
                    Cb2.Text = "";
                }
            }
        }
    }
}