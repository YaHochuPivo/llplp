﻿using pract5;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract5
{
    /// <summary>
    /// Логика взаимодействия для AdminPageEMP.xaml
    /// </summary>
    public partial class AdminPageEMP : Page
    {
        private pract6Entities context = new pract6Entities();
        public AdminPageEMP()
        {
            InitializeComponent();
            tablic.ItemsSource = context.Info_Dolzhnost.ToList();
            Cb1.ItemsSource = context.Vhod.ToList();
            Cb2.ItemsSource = context.Smena.ToList();
        }
        private void BtDob_Cl(object sender, RoutedEventArgs e)
        {
            Info_Dolzhnost o = new Info_Dolzhnost();
            if (text1.Text == "")
            {
                Eror.Text = "Невозможно добавить сотрудника: \nОтсутствует фамилия";
                return;
            }
            else
            {
                o.Surname_Sotr = Convert.ToString(text1.Text);
            }
            if (text2.Text == "")
            {
                Eror.Text = "Невозможно добавить сотрудника: \nОтсутствует имя";
                return;
            }
            else
            {
                o.Name_Sotr = Convert.ToString(text2.Text);
            }

            o.MiddleN_Sotr = Convert.ToString(text3.Text);

            if (Cb1.SelectedItem != null)
            {
                var selected = Cb1.SelectedItem as Vhod;
                o.Vhod_ID = Convert.ToInt32(selected.ID_Vhod);
            }

            if (Cb2.SelectedItem != null)
            {
                var selected = Cb2.SelectedItem as Smena;
                o.Smena_ID = Convert.ToInt32(selected.ID_Smena);
            }

            context.Info_Dolzhnost.Add(o);
            try
            {
                context.SaveChanges();
                tablic.ItemsSource = context.Info_Dolzhnost.ToList();
            }
            catch
            {
                Eror.Text = "Невозможно добавить сотрудника:\nВозможно логин или смена уже заняты\nили отсутствуют";
            }
        }
        private void BtIzm_Cl(object sender, RoutedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Info_Dolzhnost;

                if (text1.Text == "")
                {
                    Eror.Text = "Невозможно изменить сотрудника: \nОтсутствует фамилия";
                    return;
                }
                else
                {
                    selected.Surname_Sotr = Convert.ToString(text1.Text);
                }
                if (text2.Text == "")
                {
                    Eror.Text = "Невозможно изменить сотрудника: \nОтсутствует имя";
                    return;
                }
                else
                {
                    selected.Name_Sotr = Convert.ToString(text2.Text);
                }

                selected.MiddleN_Sotr = Convert.ToString(text3.Text);

                if (Cb1.SelectedItem != null)
                {
                    var selected1 = Cb1.SelectedItem as Vhod;
                    selected.Vhod_ID = Convert.ToInt32(selected1.ID_Vhod);
                }

                if (Cb2.SelectedItem != null)
                {
                    var selected1 = Cb2.SelectedItem as Smena;
                    selected.Smena_ID = Convert.ToInt32(selected1.ID_Smena);
                }

                try
                {
                    context.SaveChanges();
                    tablic.ItemsSource = context.Info_Dolzhnost.ToList();
                }
                catch
                {
                    Eror.Text = "Невозможно изменить сотрудника:\nВозможно логин или смена уже заняты\nили отсутствуют";
                }
            }
        }
        private void BtDel_Cl(object sender, RoutedEventArgs e)
        {
            var selected = tablic.SelectedItem as Info_Dolzhnost;
            if (selected != null)
            {
                try
                {
                    context.Info_Dolzhnost.Remove(selected);
                    context.SaveChanges();
                    tablic.ItemsSource = context.Info_Dolzhnost.ToList();
                }
                catch
                {
                    Eror.Text = "Невозможно удалить сотрудника\nтак как он привязан к чеку";
                }
            }
        }
        private void tablic_Dob(object sender, SelectionChangedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Info_Dolzhnost;

                text1.Text = selected.Surname_Sotr.ToString();
                text2.Text = selected.Name_Sotr.ToString();
                text3.Text = selected.MiddleN_Sotr.ToString();
                if (selected.Vhod != null)
                {
                    Cb1.Text = selected.Vhod.Login.ToString();
                }
                else
                {
                    Cb1.Text = "";
                }
                if (selected.Smena != null)
                {
                    Cb2.Text = selected.Smena.Kolvo_hours.ToString();
                }
                else
                {
                    Cb2.Text = "";
                }
            }
        }
    }
}
