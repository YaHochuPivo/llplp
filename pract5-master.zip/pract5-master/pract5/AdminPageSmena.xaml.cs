﻿using pract5;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract5
{
    /// <summary>
    /// Логика взаимодействия для AdminPageSmena.xaml
    /// </summary>
    public partial class AdminPageSmena : Page
    {
        private pract6Entities context = new pract6Entities();
        public AdminPageSmena()
        {
            InitializeComponent();
            tablic.ItemsSource = context.Smena.ToList();
        }
        private void BtDob_Cl(object sender, RoutedEventArgs e)
        {
            Smena o = new Smena();
           
            if (text2.Text == "" || Convert.ToInt32(text2.Text) < 0)
            {
                Eror.Text = "Невозможно добавить: \nОтсутствуют часы смен\nили они отрицательные";
                return;
            }
            else
            {
                o.Kolvo_hours = Convert.ToInt32(text2.Text);
            }

            context.Smena.Add(o);
            context.SaveChanges();
            tablic.ItemsSource = context.Smena.ToList();
        }
        private void BtIzm_Cl(object sender, RoutedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Smena;

                if (text2.Text == "" || Convert.ToInt32(text2.Text) < 0)
                {
                    Eror.Text = "Невозможно изменить: \nОтсутствуют часы смен\nили они отрицательные";
                    return;
                }
                else
                {
                    selected.Kolvo_hours = Convert.ToInt32(text2.Text);
                }

                context.SaveChanges();
                tablic.ItemsSource = context.Smena.ToList();
            }
        }
        private void BtDel_Cl(object sender, RoutedEventArgs e)
        {
            var selected = tablic.SelectedItem as Smena;
            if (selected != null)
            {
                try
                {
                    context.Smena.Remove(selected);
                    context.SaveChanges();
                    tablic.ItemsSource = context.Smena.ToList();
                }
                catch
                {
                    Eror.Text = "Невозможно удалить смену\nтак как она привязана к сотруднику";
                }
            }
        }
        private void tablic_Dob(object sender, SelectionChangedEventArgs e)
        {
            if (tablic.SelectedItem != null)
            {
                var selected = tablic.SelectedItem as Smena;

               
                text2.Text = selected.Kolvo_hours.ToString();
            }
        }
    }
}
